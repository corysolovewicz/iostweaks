//
//  SSLKillSwitch.h
//  SSLKillSwitch
//
//  Created by Alban Diquet on 7/10/15.
//  Copyright (c) 2015 Alban Diquet. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for SSLKillSwitch.
FOUNDATION_EXPORT double SSLKillSwitchVersionNumber;

//! Project version string for SSLKillSwitch.
FOUNDATION_EXPORT const unsigned char SSLKillSwitchVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SSLKillSwitch/PublicHeader.h>


